// FUNGSI 1: KUIS JENIS KULIT

function checkSkin(type) {

  const resultBox = document.getElementById('quiz-result');

  const resultText = document.getElementById('result-text');

  

  resultBox.classList.remove('hidden');

  

  if (type === 'normal') {

    resultText.innerHTML = "<strong>Kulitmu cenderung NORMAL.</strong> Pertahankan kondisi ini dengan basic skincare (cleanser, moisturizer, sunscreen) agar kulit tetap sehat dan terhidrasi.";

  } else if (type === 'dry') {

    resultText.innerHTML = "<strong>Kulitmu cenderung KERING.</strong> Kulitmu butuh kelembapan ekstra. Cari skincare yang mengandung <em>Hyaluronic Acid, Ceramide,</em> atau <em>Glycerin</em> untuk memperkuat skin barrier.";

  } else if (type === 'oily') {

    resultText.innerHTML = "<strong>Kulitmu cenderung BERMINYAK.</strong> Fokus pada produk penyeimbang minyak berlebih dan pembersih pori-pori. Kandungan seperti <em>Salicylic Acid (BHA), Niacinamide,</em> atau <em>Clay</em> sangat cocok untukmu.";

  } else if (type === 'combination') {

    resultText.innerHTML = "<strong>Kulitmu cenderung KOMBINASI.</strong> Kamu mungkin perlu teknik 'multi-masking' atau menggunakan pelembap bertekstur gel di area T-Zone yang berminyak dan tekstur cream di area pipi yang kering.";

  }

  

  resultBox.scrollIntoView({ behavior: 'smooth' });

}

// FUNGSI 2: ACCORDION TANYA JAWAB (FAQ)

const faqQuestions = document.querySelectorAll('.faq-question');

faqQuestions.forEach(question => {

  question.addEventListener('click', () => {

    const faqItem = question.parentElement;

    

    faqItem.classList.toggle('active');

    

    faqQuestions.forEach(otherQuestion => {

      if (otherQuestion !== question) {

        otherQuestion.parentElement.classList.remove('active');

      }

    });

  });

});